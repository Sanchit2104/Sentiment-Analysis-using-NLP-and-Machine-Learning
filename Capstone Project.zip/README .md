# Intensity-Analysis

### Intensity Analysis using NLP and Python

## Project Overview

The objective of this project is to develop an intelligent system using Natural Language Processing (NLP) to predict the intensity in text reviews. By analyzing various parameters and processing data, the system aims to predict intensity categories such as happiness, angriness, or sadness. This predictive capability will enable proactive process optimization and contribute to overall customer satisfaction.

## Models Used

The following machine learning models were employed in the project:

1. Naive Bayes
2. Random Forest
3. Logistic Regression
4. Gradient Boosting Classifier
5. Decision Tree Classifier

## Model Performance

The accuracy achieved based on each model during evaluation is as follows:

- Naive Bayes: 70%
- Random Forest: 81%
- Logistic Regression: 79%
- Gradient Boosting: 76%
- Decision Tree: 73%

## Getting Started

### Prerequisites

Make sure you have the following dependencies installed:
 first install the three csv files
- Google Colab or Jupyter Notebook : The code can be executed on any of these platforms
- For Google Colab first upload  all the csv files in your Google Drive.
- **Python Libraries:**
  - Numpy    - import pandas as pd
  - Pandas   - import numpy as np
  - NLTK     - import nltk
  - nltk.download("stopwords")
    nltk.download("punkt_tab")
    nltk.download('wordnet')
    nltk.download('omw-1.4')
    from nltk.stem import WordNetLemmatizer
    from nltk.corpus import stopwords
    from nltk.tokenize import word_tokenize
  - RegularExpressions         - import re
  - Matplotlib                 - import matplotlib.pyplot as plt
  - String functions           - import string
  - Word Cloud                 -  pip install wordcloud from wordcloud import WordCloud
  - Vectoriser                 - from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
  - Splitting the data         - from sklearn.model_selection import train_test_split
  - RandomForestClassifier     - from sklearn.ensemble import RandomForestClassifier
  - Logistic Regression        - from sklearn.linear_model import LogisticRegression
  - Multinomial NaiveBayes     - from sklearn.naive_bayes import MultinomialNB
  - DecisionTreeClassifer      - from sklearn.tree import DecisionTreeClassifier
  - GradientBoostingClassifier - from sklearn.ensemble import GradientBoostingClassifier
  - Three Fold Cross Validation- from sklearn.model_selection import cross_val_score
  - Pipeline                   - from sklearn.pipeline import make_pipeline
  - roc,auc score and classifi - from sklearn.metrics import roc_auc_score, classification_report
    cation report
  - Accuracy Score             - from sklearn.metrics import accuracy_score

    
    

   

     
